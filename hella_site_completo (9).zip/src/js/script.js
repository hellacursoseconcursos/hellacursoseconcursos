// JavaScript para o site Hella Cursos e Concursos

document.addEventListener('DOMContentLoaded', function() {
    // Menu mobile
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Fechar menu ao clicar em um link
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navMenu.classList.remove('active');
        });
    });
    
    // Slider de depoimentos
    const testimonialSlides = document.querySelectorAll('.testimonial-slide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (testimonialSlides.length > 0) {
        let currentSlide = 0;
        
        // Esconder todos os slides exceto o primeiro
        testimonialSlides.forEach((slide, index) => {
            if (index !== 0) {
                slide.style.display = 'none';
            }
        });
        
        // Função para mostrar slide
        function showSlide(n) {
            testimonialSlides.forEach(slide => {
                slide.style.display = 'none';
            });
            testimonialSlides[n].style.display = 'block';
        }
        
        // Event listeners para botões de navegação
        if (prevBtn && nextBtn) {
            prevBtn.addEventListener('click', function() {
                currentSlide--;
                if (currentSlide < 0) {
                    currentSlide = testimonialSlides.length - 1;
                }
                showSlide(currentSlide);
            });
            
            nextBtn.addEventListener('click', function() {
                currentSlide++;
                if (currentSlide >= testimonialSlides.length) {
                    currentSlide = 0;
                }
                showSlide(currentSlide);
            });
        }
        
        // Auto-play do slider
        setInterval(function() {
            if (nextBtn) {
                nextBtn.click();
            }
        }, 5000);
    }
    
    // Detalhes dos cursos na página de cursos
    const courseDetailsContainer = document.querySelector('.course-details-container');
    const courseDetailsBtns = document.querySelectorAll('.course-details-btn');
    const courseDetails = document.querySelectorAll('.course-detail');
    const closeDetailsBtns = document.querySelectorAll('.close-details');
    
    if (courseDetailsContainer && courseDetailsBtns.length > 0) {
        // Abrir detalhes do curso
        courseDetailsBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                
                courseDetailsContainer.style.display = 'block';
                document.body.style.overflow = 'hidden'; // Impedir rolagem da página
                
                courseDetails.forEach(detail => {
                    if (detail.id === targetId) {
                        detail.style.display = 'block';
                    } else {
                        detail.style.display = 'none';
                    }
                });
            });
        });
        
        // Fechar detalhes do curso
        closeDetailsBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                courseDetailsContainer.style.display = 'none';
                document.body.style.overflow = 'auto'; // Restaurar rolagem da página
                
                courseDetails.forEach(detail => {
                    detail.style.display = 'none';
                });
            });
        });
        
        // Fechar ao clicar fora do conteúdo
        courseDetailsContainer.addEventListener('click', function(e) {
            if (e.target === courseDetailsContainer) {
                courseDetailsContainer.style.display = 'none';
                document.body.style.overflow = 'auto';
                
                courseDetails.forEach(detail => {
                    detail.style.display = 'none';
                });
            }
        });
    }
    
    // FAQ na página Área Mortuária
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            question.addEventListener('click', function() {
                // Fechar outros itens
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('active');
                    }
                });
                
                // Alternar estado do item atual
                item.classList.toggle('active');
            });
        });
    }
    
    // Efeito de rolagem suave para links de âncora
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            
            // Ignorar links que abrem detalhes de curso
            if (this.classList.contains('course-details-btn')) {
                return;
            }
            
            if (targetId !== '#') {
                e.preventDefault();
                
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Animação para o efeito dourado 3D nos títulos
    const goldTexts = document.querySelectorAll('.gold-3d-text');
    
    if (goldTexts.length > 0) {
        window.addEventListener('mousemove', function(e) {
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / window.innerHeight;
            
            goldTexts.forEach(text => {
                const dataText = text.getAttribute('data-text');
                if (dataText) {
                    const offsetX = (x - 0.5) * 4;
                    const offsetY = (y - 0.5) * 4;
                    
                    text.style.filter = `drop-shadow(${2 + offsetX}px ${2 + offsetY}px 2px var(--shadow-dark))`;
                }
            });
        });
    }
});

